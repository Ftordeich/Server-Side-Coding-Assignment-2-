const express = require("express");
const router = express.Router();
const pokemonDb = require("../modules/pokemon-db.js");
const upload = require("../modules/multer-uploader");
const fs = require("fs")
const makeArray = require("../modules/make-array");

router.get("/admin", function( req, res){
    var allPokemon = pokemonDb.getAllPokemon();
    res.render("admin", { allPokemon})

});

router.get("/newPokemon", function( req, res){
res.render("new-pokemon-form");

});
var uploader = upload.fields([ {name: "id"}, {name: "name"}, {name: "types"}, {name: "description"}, {name: "imageFile"}  ])

router.post("/newPokemon", uploader, function( req, res){

    var pokemon = 
    {
        
    id: parseInt(req.body.id), 
    name: req.body.name, 
    types: makeArray(req.body.types), 
    description: req.body.description, 
    imageUrl: req.files.imageFile[0].originalname
};

    console.log(pokemon);
var oldName = req.files.imageFile[0].filename;
var newName = req.files.imageFile[0].originalname;

fs.rename("./temp/" + oldName, "./public/images/pokemon/" + newName, function (err) {
    if (err){

    throw err 
}
console.log("file renamed successfully");
})
pokemonDb.addPokemon(pokemon);
res.redirect("/admin");





});











module.exports = router;

