// Importing required modules
const { request } = require("express");
const express = require("express");
const pokemonDb = require("../modules/pokemon-db.js");

// Setup an express Router
const router = express.Router();

// TODO Add your route handlers here
router.get("/services/pokemon", function (req, res) {
var getId = parseInt(req.query.id);
res.json(pokemonDb.getPokemonById(getId));
});

router.get("/services/pokemon/types", function (req, res){
res.json(pokemonDb.getTypeData());

});

router.get("/services/pokemon/random", function (req, res){
    var numPokemon = pokemonDb.getNumPokemon();
    var ranNumber = Math.floor(Math.random() * numPokemon);
    res.json(pokemonDb.getPokemonByArrayIndex(ranNumber));

});



// Export the router so we can access it from other JS files using require()
module.exports = router;